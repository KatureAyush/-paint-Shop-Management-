import java.awt.Canvas;
import java.awt.Color;
import java.awt.event.*;
import java.awt.FlowLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import javax.swing.JCheckBox;
import javax.swing.JFrame;

public class CheckBox extends JFrame {
    private JCheckBox c1;
    private JCheckBox c2;
    private JCheckBox c3;
     Canvas c;
    
public CheckBox()
    {
      super("Ctabhane");
        c=new Canvas();
        c.setSize(40,30);
         c.setBackground(Color.black);
        
        add(c);
        setLayout(new FlowLayout());
        setSize(300,300);
        setVisible(true);
         c1=new JCheckBox("blue");
        c2=new JCheckBox("red");
        c3=new JCheckBox("green");
        
        add(c1);
        add(c2);
        add(c3);
        
        Handler h=new Handler();
        
        c1.addItemListener(h);
        c2.addItemListener(h);
        c3.addItemListener(h);
       
    }
   private class Handler extends Canvas implements ItemListener
{
 Color color;
        public void itemStateChanged(ItemEvent e) {
            
             if(c1.isSelected() && c2.isSelected())
            {
                color=Color.magenta;
                update(color);
            }
            else if(c1.isSelected())
            {
                color=Color.BLUE;
                update(color);
            }
            else if(c3.isSelected())
            {
                color=Color.GREEN;
                update(color);
            }
            else if(c2.isSelected())
            {
                color=Color.red;
                update(color);
            }
            
        }
        
        public void update(Color abk)
        {
                c.setBackground(abk);
        }
    
}

         public static void main(String args[])
        {
              CheckBox j=new CheckBox();
              j.setSize(400,400);
              j.setVisible(true);
     }
}
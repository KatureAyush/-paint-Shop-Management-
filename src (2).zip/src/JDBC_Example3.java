import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
@WebServlet("/pro28")
public class pro28 extends HttpServlet
{
 public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException
 {
  res.setContentType("text/html");
  PrintWriter out=res.getWriter();
  String q;
  String msg="";
  try{
  Class.forName("oracle.jdbc.driver.OracleDriver");
  Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","pankaj");
  Statement stmt=con.createStatement();
  ResultSet rs=stmt.executeQuery("select * from employee");
  String empid=req.getParameter("empid");
  String empname=req.getParameter("empname");
  String emp_desig=req.getParameter("emp_desig");
  String emp_j_date=req.getParameter("emp_j_date");
  String emp_salary=req.getParameter("emp_salary");
  
  int flag=Integer.parseInt(req.getParameter("flag"));
  if(empid.equals(""))
  {
   msg="Enter EmpID first";
   flag=1;
  }
  switch(flag)
  {
   case 4:
     out.println("4 selected");
    break;
   case 5:
     rs=stmt.executeQuery("select * from employee where empid='"+empid+"'");
     if(!rs.next())
     {
      q="insert into employee values('"+empid+"','"+empname+"','"+emp_desig+"','"+emp_j_date+"','"+emp_salary+"')";
      stmt.executeQuery(q);
      msg="Insert Record Successfully...";
     }
     else
     {
      msg="Employee Id Already Exist...";
     }
    break;
   case 6:
     rs=stmt.executeQuery("select * from employee where empid='"+empid+"'");
     if(rs.next())
     {
      q="delete from employee where empid='"+empid+"'";
      stmt.executeQuery(q);
      msg="Delete Record Successfully...";
     }
     else
     {
      msg="Employee Not Exist...";
     }
    break;
   case 7:
   
     rs=stmt.executeQuery("select * from employee where empid='"+empid+"'");
     if(rs.next())
     {
      q="update employee set empname='"+empname+"', emp_desig='"+emp_desig+"', emp_j_date='"+emp_j_date+"', emp_salary='"+emp_salary+"' where empid='"+empid+"'";
      stmt.executeQuery(q);
      msg="Updated Record Successfully...";
     }
     else
     {
      msg="Employee Not Exist...";
     }
    break;
  }
  rs.close();
  stmt.close();
  con.close();
  
  }catch(Exception e){}
  res.sendRedirect("pro28index.jsp?msg="+msg);
 }
}

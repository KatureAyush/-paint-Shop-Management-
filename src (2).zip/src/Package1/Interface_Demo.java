
package package1;

interface example2 {
    void sum(int a,int b);
}
interface example
{
     public void message1();
     public void message2();
}
public class Interface_Demo implements example,example2 {
   public void message1()
     {System.out.println("Hello");
      
     }
     public void message2()
     {
          System.out.println(" Java ");
     }
     
     public void sum(int a , int b){
           int c=a+b;
         System.out.println(" Addition result  =  "+c);
     }
      public static void main(String args[])
     {
Interface_Demo f = new Interface_Demo ();
          f.message1();
          f.message2();
          f.sum(31,89);
     }
}
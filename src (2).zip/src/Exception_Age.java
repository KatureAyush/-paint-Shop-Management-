import java.util.*;
public class Exception_Age {
    
public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("enter age:");
        int age = scan.nextInt();
        try {
            if (age>18){
                System.out.println("eligible for vote");
            }else
                throw new Exception("not eligible");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

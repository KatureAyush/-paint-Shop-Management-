
public class Construct {
    String firstname;
    String lastname;   
    void setfirstname(String a){
    firstname=a;
}
    void setlastname(String b){
    lastname=b;
}
void getfirstname(){
    System.out.println("firstname="+" "+firstname);
}
void getlastname(){
    System.out.println("lastname="+" "+lastname);
}
void display(){
    System.out.println("full name="+firstname+" "+lastname);
}

Construct(){
    firstname=null;
    lastname=null;
}
Construct(String f,String l){
    firstname=f;
    lastname=l;
}
Construct(Construct s1){
    firstname=s1.firstname;
    lastname=s1.lastname;
}   
public static void main(String args[]){
    Construct s1=new Construct();
    Construct s2=new Construct("Ayush","Kature");
    Construct s3=new Construct("Chaiatanya","sharma");
    Construct s4=new Construct(s1);
s1.display();
s2.display();
s3.display();
s4.display();

s2.setfirstname("Aman");
s2.display();

s2.setlastname("Walde");
s2.display();

s3.getfirstname();

s3.getlastname();   
}
}


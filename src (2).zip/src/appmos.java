import java.awt.*;
import java.applet.*;
import java.awt.event.*;
public class appmos extends Applet
{	String s=null;
	public boolean mouseup(Event e,int x,int y)
{ 	s="GHRCE";
	repaint();
	return(true);
}
public void paint(Graphics g)
{ if(s!=null)
	{ for(int i=10;i<=50;i+=10)
		{	Color c=new Color(106-i,256-i*3,256-i*2);
			g.setColor(c);
			g.fillOval(30+i*5,30+i*5,80+i*2,40+i*2);
                        g.drawOval(86,42,20,12);
		        
			}}}}
import java.awt.*;
import java.awt.Canvas;
import java.applet.*;
import java.awt.event.*;
public class ColourChanges extends Applet implements ItemListener {
    Checkbox Red,Green,Blue;
    int a,b,c=0;
    
    Font f= new Font(" Times New Roman",Font.BOLD,16);
    public void init(){
         Canvas cn;
        
         cn=new Canvas();
        cn.setSize(40,30);
         cn.setBackground(Color.black);
        
        add(cn);
        setLayout(new FlowLayout());
        setSize(300,300);
        setVisible(true);
        
        Red= new Checkbox("Red");
        Green= new Checkbox("Green");
        Blue=new Checkbox("Blue");
        Red.setBounds(100, 100, 100, 50);
        Green.setBounds(300, 100, 100, 50);
        Blue.setBounds(500, 100, 100, 50);
        add(Red);
        add(Green);
        add(Blue);
        Red.addItemListener(this);
        Green.addItemListener(this);
        Blue.addItemListener(this);
        
    }
    public void itemStateChanged(ItemEvent e){
        
        if (Red.getState()==true){
             a=255;    
        }
        else{
            a=0;
        } 
        if (G.getState()==true){
             y=255;
        }
        else {
            y=0;
        }
        if(B.getState()==true){
             z=255;     
        }
        else{
            z=0;
        }
        Color c= new Color(x,y,z);
        setBackground(c);
       
        
    }     
}
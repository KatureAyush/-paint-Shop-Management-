import java.applet.Applet;
import java.awt.*;
public class AppletDemo extends Applet
{
public void init()
{
setBackground(Color.cyan);
}
public void paint(Graphics g)
{
Font f=new Font("TIMES NEW ROMAN ",Font.ITALIC,32);
g.setFont(f);
g.setColor(Color.orange);
g.drawString("WELCOME TO APPLET ",30,30);
g.fillOval(60,60,150,150);
g.setColor(Color.black);
g.fillOval(90,100,20,20);
g.fillOval(160,100,20,20);
g.setColor(Color.RED);
g.drawLine(120,150,150,150);
g.drawLine(120,150,140,130);
g.drawArc(90,130,90,60,0,-180);
}
}
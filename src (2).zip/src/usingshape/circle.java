
package usingshape;

public class circle implements Shape {
	private double radius;
	public circle(double r){
	this.radius = r;
	}
	public void draw() {
		System.out.println("Drawing Circle");
	}
	public double getArea(){
		return Math.PI*this.radius*this.radius;
	}
	public double getRadius(){
		return this.radius;
	}
}

package Package_Account;

public class CurrentAccount {
    private double overdraft;

    public CurrentAccount(double interest, int a ,double overdraft) {
        this.overdraft = overdraft;
    }

    public double getOverdraft() {
        return overdraft;
    }

    public void setOverdraft(double overdraft) {
        this.overdraft = overdraft;
    }
}

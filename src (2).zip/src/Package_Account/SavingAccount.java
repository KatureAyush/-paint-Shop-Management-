
package Package_Account;

import java.io.Serializable;

    public class SavingAccount extends Account_class implements Serializable {
    private double interest;
    
    //Account Account_object = new Account("bal", "accnun");

    public SavingAccount(double interest, int a) {
        super(a);
        this.interest = interest;
    }

    public double getInterest() {
        return interest;
    }

    public void setInterest(double interest) {
        this.interest = interest;
        
   // @Override
   // public void setInterest(double interest) {
    super.getBalance();     
    }
}


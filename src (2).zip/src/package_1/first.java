
package package_1;


public interface first {
    public String LABLE="A";
    void meth1();
    void meth2();

}


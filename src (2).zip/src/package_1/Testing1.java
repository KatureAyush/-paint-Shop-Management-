
package package_1;


public class Testing1 {
    
    public static void main(String[] args) {
        first first=new Myclass(12,15,25);
		first.meth1();
		first.meth2();
    }
}
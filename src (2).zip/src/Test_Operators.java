
//function overloading
class Adder{  
static int add(int a, int b){
    return a+b;
    }  
static double add(double a, double b){return a+b;} }
//function overloading
class subtract{  
static int sub(int a, int b){
    return a-b;
    }  
static double sub(double a, double b){return a-b;} }
//Function overriding
class Multiply extends Adder{
int getcalculation(int a , int b){return a*b;}  }  
  //Function overriding
class Div extends subtract{  
int getcalculation(int a , int b){return a/b;}  
}  
public class Test_Operators {
    static int add(int x, int y)
    {
    return (x + y);
    }
public static void main(String[] args){ 
    
System.out.println("code Written by AYUSH KATURE");     
System.out.println(Adder.add(25,11));  
System.out.println(Adder.add(33.3,12.6));  
System.out.println(subtract.sub(11,11));  
System.out.println(subtract.sub(22.3,12.6)); 
System.out.println(Test_Operators.add(5,10));

// Function Overriding
Multiply s=new Multiply();  
Div i=new Div();
System.out.println(s.getcalculation(40, 20));  
System.out.println(i.getcalculation(30,10));  
}}

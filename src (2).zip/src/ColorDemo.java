import java.awt.*;
import java.applet.*;
/* <applet code="ColorDemo" width="700" height="600">
	</applet>  */
	public class ColorDemo extends Applet {
		public void init() {
			setBackground(Color.CYAN);
			//setForeground(Color.RED);
		}
		public void paint(Graphics g) {
			// for drawing a string
			g.setColor(Color.DARK_GRAY);
			g.drawString("JAVA",160,100);
			g.setColor(Color.BLUE);
			g.drawString("applet",10,10);
			// for line draw
			g.drawLine(50,50,100,150);
                        g.drawLine(150,70,110,250);
			g.setColor(Color.RED);
			// for Rectangle
			g.drawOval(100,100,50,50);
                        g.drawOval(150,80,100,120);
			Color c = new Color(155,34,190);
			g.setColor(c);
			g.fillOval(120,120,20,20);
                        g.fillOval(160,130,40,40);
		}
	}

    //Program to throw implement division and throw exceptions
import java.util.*;
class NAexception
{
            public static void main(String args[])
            {
                        Scanner src=new Scanner(System.in);
                        int num1,num2,q;
                        
                        try
                        {
                                    // input numbers here.
                                    System.out.println("\nEnter the value of first integer : ");
                                    num1=Integer.parseInt(src.next());
                                    
                                    System.out.println("\nEnter the value of second integer : ");
                                    num2=Integer.parseInt(src.next());
                                    
                                    //throw to catch
                                    q=num1/num2;
                                    System.out.println("\nQuotient is : "+q);
                        }
                        catch(NumberFormatException e)
                        {
                                    System.out.println("Error:"+e);
                        }
                        catch(ArithmeticException e)
                        {
                                    System.out.println("Error:"+e);
                        }
            }
}


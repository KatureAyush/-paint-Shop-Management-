import java.awt.*;
import java.applet.Applet;
public class FrameInApplet extends Applet
{
public void init()
{
  MyFrame frame= new MyFrame(" Frame in an applet");
  frame.setBounds(20,50,250,150);
  frame.setVisible(true);
}
}
class MyFrame extends Frame
{
	MyFrame ( String s)
	{
		super(s);
		setLayout (new FlowLayout(FlowLayout.CENTER));
		TextField tf= new TextField("Type Text");
		add(tf);
		add(new Button("OK"));
	}
}

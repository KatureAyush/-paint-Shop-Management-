public class Exception_Demo1 {
    public static void main(String[] args)
    {
        try{
            int c= calculate(7,1);
            System.out.println(c);
             }
        catch (Exception e)
        {
            System.out.println("Exception occured"+e.toString());
            e.printStackTrace();
        }
    }           
static int calculate(int a, int b)  {
            int c=a/b;
            return c;
        }
    }

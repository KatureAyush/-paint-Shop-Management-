
public class Swapping {
    
    void change(int m,int n)
    {
        m= m * 2;
        n= n + 3;
        System.out.println("The value of m ="+m+"and the value of n ="+n);
    }
    public static void main(String args [])
    {
        Swapping S1=new Swapping();
        int a=10,b=12;
        System.out.println("Before :The value of a = "+ a +"the value of b ="+b);
        S1.change(a,b);
        System.out.println("After :The value of a = "+ a +"the value of b ="+b);
        S1.change(a,b);
    }
}

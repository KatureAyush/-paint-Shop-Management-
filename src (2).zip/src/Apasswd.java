import java.awt.*;
import java.applet.*;
import java.awt.event.*;
public class Apasswd extends Applet implements ActionListener
{
       String msg,pass,s1,usr;
        Button c1;
        TextField t1,t2;
        Label l1,l2;
        Font f=new Font("Bookman Old Style",Font.BOLD,16);
        public void init()
        {     
              setBackground(Color.pink);
              setLayout(null);
              setFont(f);
              l1=new Label("Enter Username");
              t1=new TextField(15);
              l2=new Label("Enter Password");
              t2=new TextField(15);
              t2.setEchoChar('*');
              c1=new Button("Submit");
              l1.setBounds(30,30,140,20);
              t1.setBounds(170,30,200,25);
              l2.setBounds(30,50,140,20);
              t2.setBounds(170,50,200,25);
              c1.setBounds(200,100,70,55);
              add(l1);
              add(t1);
              add(l2);
              add(t2);
              add(c1);
              c1.addActionListener(this);
        }
        public void actionPerformed(ActionEvent ae)
        {
              usr=t1.getText();
              pass=t2.getText();
              msg=ae.getActionCommand();
              if(msg.equals("Submit"));
              {
	if(usr.equals("admin")&&pass.equals("password"))
	showStatus("Password is Correct");
	else
	showStatus("Password is Incorrect");
              }
         }
}

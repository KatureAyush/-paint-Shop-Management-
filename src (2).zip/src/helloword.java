import java.awt.*;
import java.applet.*;

public class helloword extends Applet{
public void paint(Graphics g)
{
	g.drawString("hello java",50,50);
}}

package itempack;

/**
 *
 * @author ayush
 */
public interface calAmount {
    public void CalculateAmount();
            
}


import java.util.Scanner;
class factorial extends Thread
{  	public void run()    {  
  int i,fact=1;  
  int number=5;//It is the number to calculate factorial    
  for(i=1;i<=number;i++){    
      fact=fact*i;    
  }    
  System.out.println("Factorial of "+number+" is: "+fact);    
 }  
}

class evenodd extends Thread
{  public void run()   {

        Scanner reader = new Scanner(System.in);

        System.out.print("Enter a number: ");
        int num = reader.nextInt();

        if(num % 2 == 0)
            System.out.println(num + " is even");
        else
            System.out.println(num + " is odd");
    }
}
class fibonacci extends Thread
{  public void run()   {    
 int n1=0,n2=1,n3,i,count=10;    
 System.out.print(n1+" "+n2);//printing 0 and 1    
    
 for(i=2;i<count;++i)//loop starts from 2 because 0 and 1 are already printed    
 {    
  n3=n1+n2;    
  System.out.print(""+n3);    
  n1=n2;    
  n2=n3;    
 }    
  
}
}
class multhread
{    public static void main(String args[])
	{
		new factorial().start();
		new evenodd().start();
		new fibonacci().start();
	}
}
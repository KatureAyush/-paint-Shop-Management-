
import java.io.*;
 public class threadtester
{
 public static void main(String args[])
 {
 Thread thread1,thread2,thread3,thread4;
 thread1=new printthread("thread1");
 thread2=new printthread("thread2");
 thread3=new printthread("thread3"); 
 thread4=new printthread("thread4");
 System.err.println("\n starting threads");
 thread1.start();
 thread2.start();
 thread3.start();
 thread4.start();
 System.err.println("threads started\n");
 }
}
 class printthread extends Thread
 { 
 private int sleeptime;
 public printthread(String name)
 {
 super(name);
 sleeptime=(int)(Math.random()*5000);
 System.err.println("name:"+getName()+"slee:"+sleeptime);   
 }
public void run()
{
try
{
System.err.println(getName()+"going to sleep");
Thread.sleep(sleeptime);
}
catch(InterruptedException exception)
{
System.err.println(exception.toString());
}
System.err.println(getName()+"done sleeping");
}
}

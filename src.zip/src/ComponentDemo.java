import java.awt.*;
public class ComponentDemo extends Frame {
	private Label lbl1;
	private Label lbl2;
	private TextField txt1;
	private TextField txt2;
	private TextField txt3;
	private Button btn1,btn2;
	public ComponentDemo() {
		setLayout(new FlowLayout());
		lbl1=new Label();
		lbl2=new Label("Enter Employee #");
		txt1=new TextField("110");
		txt2=new TextField("KAMAL");
	    txt3=new TextField("KAMAL",10);
	    btn1=new Button("Submit");
	    btn2=new Button("OK");
         add(lbl1);
add(lbl2);
add(txt1);
add(txt2);
add(txt3);
add(btn1);
add(btn2);
}
public static void main(String args[]) {
	ComponentDemo demo=new ComponentDemo();
	demo.setSize(400,400);
	demo.setVisible(true);
}
}

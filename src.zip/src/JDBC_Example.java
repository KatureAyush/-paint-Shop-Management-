import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
public class JDBC_Example {
   static final String DB_URL = "jdbc:derby://localhost:1527/Student_info";
   static final String DB_DRV =  "org.apache.derby.jdbc.ClientDriver";
   static final String DB_USER = "Ayush1";
   static final String DB_PASSWD = "ayush@4238";
   public static void main(String[] args){
      Connection connection = null;
      Statement statement = null;
      ResultSet resultSet = null;
      try{
         connection=DriverManager.getConnection (DB_URL,DB_USER,DB_PASSWD);
         statement=connection.createStatement();
         resultSet=statement.executeQuery  ("SELECT * FROM STUDENT_PERFORMANCE");
 while(resultSet.next()){
           // System.out.printf("%s\t %d\t %s\t %s\t %s\t %s\n", resultSet.getString(1),resultSet.getInt(2), resultSet.getString(3),resultSet.getString(4),resultS
 System.out.println( resultSet.getString(1) + resultSet.getInt(2) + resultSet.getString(3)+resultSet.getString(4)+resultSet.getInt(5)); 
 }
 }
      catch(SQLException ex){
      }
      finally{
         try {
            resultSet.close();
            statement.close();
            connection.close();
         } catch (SQLException ex) {
         }
      }
   }
}
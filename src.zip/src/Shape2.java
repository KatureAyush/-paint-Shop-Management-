 
public class  Account
{
	private double bal;  //The current balance
	private int accnum;  //The account number
	
	
	public Account(int a)
	{	
	bal=0.0;
	accnum=a;
	}
	
	public void deposit(double sum)
	{
	if (sum>0)
		bal+=sum;	
	else
		System.err.println("Account.deposit(...): "
				   +"cannot deposit negative amount.");	
	}
	
	public void withdraw(double sum)
	{
	if (sum>0)
		bal-=sum;	
	else
		System.err.println("Account.withdraw(...): "
				   +"cannot withdraw negative amount.");	
	}
	
	public double getBalance()
	{
	return bal;
	}
	
	public double getAccountNumber()
	{
	return accnum;
	}
	
	public String toString()
	{
	return "Acc " + accnum + ": " + "balance = " + bal;	
	}
	
	public final void print()
	{
	//Don't override this,
	//override the toString method
	System.out.println( toString() );	
	}
	
}

// This is What i have done so Far...
public class SavingsAccount extends Account{
	
	private double interest;//additional attribute to previous attributes of class Account.
		
	public SavingsAccount(int accnum, double interest){
		super(accnum);
		this.interest=interest;
	}//end of constructor.
	
	// method to get interest.
	public double getInterest(){
		 double x=super.getBalance()*interest;
		 return x;
	}
	
	//method to set interest.
	public void setInterest(double interest){
		this.interest=interest;
	}
	
	// method to add interest to account.
	public void  AddInterest (double interest){
		double x=super.getBalance()*interest;
		super.deposit(x);
	}
	
	// override the toString() method.
	public String toString(){
		return super.toString()+" Interest : "+interest;
	}
	
	
	
}//end of class SavingsAccount.

public class CurrentAccount extends Account{
	
	private double limit;// additional variable to know limit of overdraft
	
	
	public CurrentAccount(int accnum, double limit){
		super(accnum);
		this.limit=limit;
	}//end of constructor.
	
	// method to get Limit.
	public double getLimit(){
		return this.limit;
	}
	
	//method to set limit.
	public void setLimit(double limit){
		this.limit=limit;
	}
	//method to withdraw limit only
	public void withdraw( double limit){
		if(limit<=this.limit)
			super.withdraw(limit);
		else{
			System.out.println(" Sorry, Limit Exceeded" );
		}
	}// end method.
	
	// override the toString() method.
	public String toString(){
		return super.toString()+" Limit : "+limit;
	}
	
	
	
}

public class Shape2 {
   
    public static void main(String[] args) {
      SavingsAccount Account_object = new SavingsAccount(560, 4570012);
      System.out.println("Program by: Chaitanya Tabhane A-25" );
      System.out.println("Account Number: "+ Account_object.getAccountNumber());
      System.out.println("Account Balance plus Interest is: "+Account_object.getInterest());
      System.out.println(" Total Intrest on Saving Account is: "+Account_object.getInterest()+Account_object.getAccountNumber());
       // TODO code application logic here
    }
}
//Write a Java Program to implement frames
import java.awt.*;
import java.awt.event.*;
public class Framesample extends Frame
{        public Framesample()
	{      setTitle("Clock");
		setBackground(new Color(128,255,255));
			addWindowListener(new WH());
	}
class WH extends WindowAdapter
{	public void windowClosing(WindowEvent e)
	{	System.exit(0);
	}}
public void paint(Graphics g)
{	g.setColor(new Color(128,0,0));
	g.drawOval(100,100,280,260);
	g.drawOval(120,120,240,220);
	g.fillOval(230,130,15,15);
	g.fillOval(230,310,15,15);
	g.fillOval(330,220,15,15);
	g.fillOval(130,220,15,15);
	g.fillOval(280,150,10,10);
	g.fillOval(310,180,10,10);
	g.fillOval(320,270,10,10);
	g.fillOval(280,300,10,10);
	g.fillOval(150,270,10,10);
	g.fillOval(180,300,10,10);
	g.fillOval(180,150,10,10);
	g.fillOval(150,180,10,10);
	g.drawLine(270,187,240,234);
	g.drawLine(270,188,240,235);
	g.drawLine(270,186,240,233);
	g.drawLine(270,185,240,232);
	g.fillOval(235,226,10,10);
        g.drawLine(237,230,280,330);
	g.drawLine(237,231,280,261);
}
public static void main(String args[])
{	Framesample s=new Framesample();
	s.setBounds(1,1,600,600);
	s.setVisible(true);
}}


   class abc implements Runnable 
   {
       public void run() 
   { for(int i=1;i<10;i++) 
   { 
       System.out.println("Thread abc:"+i);
   } 
   System.out.println("End of thread abc");
   } 
   } 
   class threadrun { public static void main(String args[])
   { 
       abc Runnable=new abc();
       Thread xyz=new Thread (Runnable);
       xyz.start();
       System.out.println("end of main thread");
   } } 


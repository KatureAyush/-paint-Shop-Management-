import java.io.IOException;
import java.util.Scanner;

public class Main
{
	static void ex(int a)
	{	
		try
		{
			int c =50/0;
		}
		catch(ArithmeticException e)
		{
			System.out.println("dividing a number by zero cannot be defined");
		}
		finally
		{
			System.out.println("this statement will always be executed");
		}

		if(a>=18)
			System.out.println("The person is  eligible to vote");
		else
			System.out.println("the person is not eligible to vote");
	}

	public static void main(String [] args) throws Exception
	{ 
		Scanner sc = new Scanner(System.in);
		System.out.println("enter the age of a person to check for voting");
		int c =sc.nextInt();
		ex(c);
		System.out.println("This is written inside main function");
	}
}

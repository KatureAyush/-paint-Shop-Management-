import java.applet.Applet;
import java.awt.*;
public class FaceDemo extends Applet implements Runnable {
	int x1,x2;
	public void init() {
		Thread t = new Thread(this);
		x1 = 55;
		x2 = 100;
		t.start();
	}
	public void run() {
		while(true) {
			try {
				Thread.sleep(500);
				if(x1==55) {
					x1 = 45;
					x2 = 90;
				}else {
					x1= 55;
					x2 = 100;
				}
				repaint();
			}
			catch(Exception e) {
				System.out.println("Error : " + e);
			}
		}
	}
	public void paint(Graphics g) {
		g.drawOval(22,16,100,104);
		g.drawOval(14,48,10,20);
		g.drawOval(122,48,10,20);
		g.drawOval(42,42,20,12);
		g.drawOval(86,42,20,12);
		g.fillOval(x1,48,8,6);
		g.fillOval(x2,48,8,6);
		g.drawLine(76,50,68,80);
		g.drawLine(68,80,82,80);
		g.drawLine(60,90,88,90);
		g.drawArc(60,88,28,6,180,180);
	}  }
import java.awt.*;
	import java.awt.event.*;
	class ItemEventDemo extends Frame implements ItemListener {
		Checkbox chk1,chk2,chk3;
		CheckboxGroup cbg;
		TextField txt;
		public ItemEventDemo() {
			setLayout(new FlowLayout());
			setFont(new Font("Arial",Font.BOLD,30));
			cbg = new CheckboxGroup();
			chk1 = new Checkbox("Windows",cbg,false);
			chk2 = new Checkbox("Unix",cbg,false);
			chk3 = new Checkbox("Linux",cbg,false);
			txt = new TextField(25);
			add(chk1);
			add(chk2);
			add(chk3);
			add(txt);
			chk1.addItemListener(this);
			chk2.addItemListener(this);
			chk3.addItemListener(this);
		}
		public void itemStateChanged(ItemEvent ie) {
			String str= "";
			Checkbox chk = (Checkbox)ie.getSource();
			if(chk == chk1) {
				str = chk1.getLabel();
			}else if(chk == chk2) {
				str = chk2.getLabel();
			}else if(chk == chk3) {
				str = chk3.getLabel();
			}
			txt.setText(str);
		}
		public static void main(String args[]) {
			ItemEventDemo demo = new ItemEventDemo();
			demo.setSize(400,400);
			demo.setVisible(true);
		}
	}
                                
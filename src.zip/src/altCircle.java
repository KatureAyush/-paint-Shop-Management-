import java.awt.*;
  import java.applet.*;

  public class altCircle extends Applet
  {
         public void paint(Graphics g){
             Dimension d = getSize();
             int circleHeight = 50;
             int circleWidth = 50;

             //To bring circle in the center of the canvasint x = (d.width/2) - (circleHeight/2);  

             for (int i=0;i<5;i++ )
             {
                     if (i%2 == 0)
                     {
                             g.setColor(Color.green);
                             g.drawOval(x,i*60 + 10, circleWidth,circleHeight);
                     }
                     else
                     {
                            g.setColor(Color.red);
                             g.fillOval(x,i*60 + 10, circleWidth,circleHeight);
                     }
             }
        }
  }


package Package_Account;


public class Bank_class {
    public static void main(String[] args) {
        Account_class[] accounts = new Account_class[2];
        accounts[0] = new SavingAccount(2,1);     
        accounts[1] = new SavingAccount(3, 4);

        for(int i=0; i<accounts.length;i++) {
            if(accounts[i].equal (SavingAccount)
                System.out.println(accounts[0].getIntrest());
        }
}
}
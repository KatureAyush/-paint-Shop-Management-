
package Package_Account;

public class Account_class {
    private double bal;  //The current balance
    private int accnum;  //The account number
    
    
    public Account_class(int a)
    {    
	bal=0.0;
	accnum=a;
    }
    public void deposit(double amount)
    {
	if (amount>0)
	    bal+=amount;  
       
	else
	    System.err.println("Account.deposit(...): " +"cannot deposit negative amount.");    
    }
    public void withdraw(double amount)
    {
	if (amount>0)
	    bal-=amount;    
	else
	    System.err.println("Account.withdraw(...): "+"cannot withdraw negative amount.");    
    }
    public double getBalance()
    {
	return bal;
    }
      public double getAccountNumber()
    {
	return accnum;
    }
    
    public String toString()
    {
	return "Acc " + accnum + ": " + "balance = " + bal;    
    }


}

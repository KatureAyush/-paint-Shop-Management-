
package Package_Account;

public class Shapetest {
   
    public static void main(String[] args) {
      SavingAccount Account_object = new SavingAccount(560, 4570012);
      System.out.println("Program by: Siddesh Maske" );
      System.out.println("Account Number: "+ Account_object.getAccountNumber());
      System.out.println("Account Balance plus Interest is: "+Account_object.getInterest());
      System.out.println(" Total Intrest on Saving Account is: "+Account_object.getBalance());
       // TODO code application logic here
    }
}

import java.awt.*;
import java.awt.event.*;
import java.applet.*;



public class DemoExample extends Applet implements ActionListener {
	String msg;
	TextField input1,input2,result ;
	Label A, B, C;
	Button div;

	public void init() {
		A = new Label("Number1");
		B = new Label("Number2");
		C = new Label("Result");
		input1 = new TextField(15);
		input2 = new TextField(15);
		result = new TextField(15);
		div = new Button("Click");
		div.addActionListener(this);
		add(A);
		add(input1);
		add(B);
		add(input2);
		add(C);
		add(result);
		add(div);
	}

	public void actionPerformed(ActionEvent mg) {
		String arg = mg.getActionCommand();
		int input1 = 0, input2 = 0;
		if (arg.equals("Click")) {
			if (this.input1.getText().isEmpty() && this.input2.getText().isEmpty()) {
				msg = "Enter the valid numbers!";
				repaint();
			} else {
				try {
					input1 = Integer.parseInt(this.input1.getText());
					input2 = Integer.parseInt(this.input2.getText());

					int num3 = input1 / input2;

					result.setText(String.valueOf(num3));
					msg = "Output got Succesfully!!!";
					repaint();
				} catch (NumberFormatException ex) {
					System.out.println(ex);
					result.setText("");
					msg = "NumberFormatException - Invalid Entry";
					repaint();
				} catch (ArithmeticException e) {
					System.out.println("Can't be divided by Zero" + e);
					result.setText("");
					msg = "Can't be divided by Zero";
					repaint();
				}
			}
		}
	}

	public void paint(Graphics g) {
		g.drawString(msg,30, 170);
	}
}
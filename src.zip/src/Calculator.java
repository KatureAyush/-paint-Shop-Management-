
    public class Calculator {
    
    public static void main(String[] args)
    {
        float a=10,b =5,c;
        
        c=a+b;
        System.out.println("addition result=" +c);
        c=a%b;
        System.out.println("Modular division result=" +c);
        c=a-b;
        System.out.println(" Subtraction  result=" +c);
        c=a*b;
        System.out.println(" Multiplication  result=" +c);
        c=a/b;
        System.out.println(" Division  result=" +c);
    }
}


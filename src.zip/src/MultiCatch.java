
import java.util.Scanner;

public class MultiCatch
{  
	public static void main(String arg[])
    {  
		try
		{
			int N1,N2,Y;
			Scanner obj=new Scanner(System.in);
			
			// input numbers here.
			System.out.print("Enter first number : ");
			N1=obj.nextInt();
       
			System.out.print("Enter second number : ");
			N2=obj.nextInt();
       
			//throw to catch
			Y=25;
			System.out.println("Result:"+c);
		}
		catch(ArithmeticException e)
		{
			System.out.println("Error:"+e.getMessage());
			System.out.println("Error:"+e);
		}
		catch(NumberFormatException  e)   
		{    
            System.out.println("Error:"+e.getMessage());   
            System.out.println("Error:"+e);
		    
		}  
		// here program ends.
		System.out.println("End of Program...");
	}
}
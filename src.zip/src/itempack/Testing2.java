
import itempack.*;



public class Testing2 {
    public static void main(String[] args) {
        Item I1 =new Item (01,"Mango juice",90.0,5);
        I1.displayItem();
        I1.CalculateAmount();
        Item I2 =new Item (02,"cake",450.0,1);
        I2.displayItem();
        I2.CalculateAmount();
        Item I3 =new Item (01,"pineapple juice",100.0,3);
        I3.displayItem();
        I3.CalculateAmount();
}
}

package itempack;


    public class Item implements calAmount{
    int Itemcode;
    String Itemname;
    double rate;
    int quantity;

    public Item(int c,String N ,double r, int Q){
    Itemcode=c;
    Itemname=N;
    rate=r;
    quantity= Q;
}
public void displayItem(){
    System.out.println("Item list:");
    System.out.println("Code :"+Itemcode+"\t"+"Name:"+Itemname+"\t"+"Rate:"+rate+"\t"+"Quantity:"+quantity);
}
public void CalculateAmount(){
    System.out.println("Total Amount:"+rate*quantity);
}
}


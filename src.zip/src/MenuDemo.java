import java.awt.*;
	import java.awt.event.*;
	class MenuDemo extends Frame implements ActionListener {
		MenuBar mbar;
		Menu mFile,mEdit,mHelp;
		MenuItem miNew,miOpen,miSave,miExit;
		MenuItem miCut,miCopy,miPaste;
		Menu mColor;
		MenuItem miAbout,miContent;
		MenuItem miRed,miGreen,miBlue,miNoFill;
		public MenuDemo() {
			mbar = new MenuBar();
			mFile = new Menu("File");
			mEdit = new Menu("Edit");
			mColor = new Menu("Color");
			mHelp = new Menu("Help");
			miNew = new MenuItem("New");
			miOpen = new MenuItem("Open");
			miSave = new MenuItem("Save");
			miExit = new MenuItem("Exit");
			miCut  = new MenuItem("Cut");
			miCopy  = new MenuItem("Copy");
			miPaste = new MenuItem("Paste");
			miRed= new MenuItem("Red");
			miGreen= new MenuItem("Green");
			miBlue= new MenuItem("Blue");
			miNoFill= new MenuItem("No Fill");
			miAbout = new MenuItem("About");
			miContent = new MenuItem("Content");
			mColor.add(miRed);
                        mColor.add(miGreen);
			mColor.add(miBlue);
			mColor.add(miNoFill);
mFile.add(miNew); mFile.add(miOpen);
 mFile.add(miSave); mFile.add(miExit);
			mEdit.add(miCut); mEdit.add(miCopy); mEdit.add(miPaste); 
                                    mEdit.add(mColor);
			mHelp.add(miAbout); mHelp.add(miContent);
			mbar.add(mFile);
			mbar.add(mEdit);
			mbar.add(mHelp);
			setMenuBar(mbar);
			miRed.addActionListener(this);
			miGreen.addActionListener(this);
			miBlue.addActionListener(this);
			miNoFill.addActionListener(this);
		}
		public void actionPerformed(ActionEvent ae) {
			String str = ae.getActionCommand();
			if(str.equals("Red")) {
				this.setBackground(Color.red);
			}
			if(str.equals("Green")) {
				this.setBackground(Color.green);
			}
			if(str.equals("Blue")) {
				this.setBackground(Color.blue);
			}
			if(str.equals("No Fill")) {
				this.setBackground(Color.white);
			}
		}
		public static void main(String args[]) {
                        MenuDemo demo = new MenuDemo();
			demo.setSize(400,400);
			demo.setVisible(true);
		}
	}


import java.awt.*;
import java.applet.*;
public class Font_Demo extends Applet
{	public void init()
	{
              setBackground(Color.cyan);
	}
	public void paint(Graphics g)
	{	Font f1,f2,f3;
		f1=new Font("Bookman Old Style",Font.BOLD,20);
		f2=new Font("Arial",Font.BOLD,23);
		f3=new Font("Times New Roman",Font.BOLD,23);
		g.setFont(f1);
                           g.setColor(Color.blue);
		g.drawString("Welcome to",100,100);
		g.setFont(f2);
                           g.setColor(Color.MAGENTA);
		g.drawString("G.H.Raisoni College of Engineering",125,125);
		g.setFont(f2);
                           g.setColor(Color.green);
		g.drawString("Electronics & Telecommunication Engineeriong",120,150);
		g.setFont(f3);
                g.setFont(f1);
                           g.setColor(Color.yellow);
		g.drawString("Student Name is:Ayush kature",130,180);
                g.setFont(f1);
                           g.setColor(Color.orange);
		g.drawString("Sec/Rollno:'A' 22",120,205);
	}}

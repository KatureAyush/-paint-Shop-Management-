
package package_1;

public class Myclass implements first{
        private int num1;
	private int num2;
        private int num3;
        
	public Myclass(int x, int y,int z){
		num1=x;
		num2=y;
                num3=z;
	}
	public void meth1() {
                System.out.println("Code is Written by Ayush kature");
		System.out.println("addition of three numbers");
                System.out.println(num1+num2+num3);
                
	}
	public void meth2() {
                System.out.println("multiplication of three number:");
                System.out.println(num1*num2*num3);
	}

    
}


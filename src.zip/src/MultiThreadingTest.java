
import java.util.Random;
class Thread1 extends Thread
{
 int A;
 Thread1(int n)//parametrised constructor
 {
 A = n;
 }
 public void run()
 {
 int sqr = A *A;
 System.out.println("Square of " + A + " = " + sqr );
 }
}
class Thread2 extends Thread
{
 int B;
 Thread2(int n)//Parametrised constructor
 {
 B= n;
 }
 public void run()
 {
 int cub = B * B * B;
 System.out.println("Cube of " + B + " = " + cub );
 }
}
class Thread3 extends Thread
{
 public void run()
 {
 Random random = new Random();
 for(int i =0; i<9; i++)
 {
 int randomInteger = random.nextInt(100);
 if((randomInteger%2) == 0) {
 System.out.println("Random Integer generated : " + randomInteger);
 Thread1 T1 = new Thread1(randomInteger);
 T1.start();
 }
 else {
 Thread2 T2 = new Thread2(randomInteger);
 T2.start();
 }
 try {
 Thread.sleep(1000);//generation of random integer after 1 sec.
//This thread generates random number 9 times
//between 1 to 100 for every 1 second. The generated
//random number is then passed as argument to Square and Cube threads.
//Output varies each time a program is executed.
 } catch (InterruptedException ex) {
 System.out.println(ex);
}
 }
 }
}
public class MultiThreadingTest {
 public static void main(String args[])
 {
 Thread3 n = new Thread3();
 n.start();
 }
}


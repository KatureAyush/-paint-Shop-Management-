import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
public class JDBC_example12 {
   static final String DB_URL = "jdbc:derby://localhost:1527/Employee_info";
   static final String DB_DRV =  "org.apache.derby.jdbc.ClientDriver";
   static final String DB_USER = "Ayush1";
   static final String DB_PASSWD = "Ayush";
   public static void main(String[] args){
      Connection connection = null;
      Statement statement = null;
      ResultSet resultSet = null;
      try{
         connection=DriverManager.getConnection (DB_URL,DB_USER,DB_PASSWD);
         statement=connection.createStatement();
         resultSet=statement.executeQuery  ("SELECT * FROM EMP_INFO");
 while(resultSet.next()){
     System.out.println( resultSet.getInt(1) + resultSet.getString(2) + resultSet.getString(3)+resultSet.getString(4)+resultSet.getDouble(5));
           // System.out.printf("%s\t %d\t %s\t %s\t %s\t %s\n", resultSet.getString(1),resultSet.getInt(2), resultSet.getString(3),resultSet.getString(4),resultS
}
}
      catch(SQLException ex){
      }
      finally{
         try {
            resultSet.close();
            statement.close();
            connection.close();
         } catch (SQLException ex) {
         }
      }
   }
}


public class Multiple_Interface {
    
}

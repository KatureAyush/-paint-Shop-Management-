
public class TestStudent4 {
    
    public static void main(String args[]){
     Student4 s1=new Student4();
     Student4 s2=new Student4();
     s1.insertRecord(111,"Karan",123452,7.8,9.3);
     s2.insertRecord(222,"Aryan",672663,9.3,8.7);
     s1.displayInformation();
     s2.displayInformation();
         }
         }
         class Student4{
         int rollno, contact;
         String name;
         double sgpa, cgpa;
         void insertRecord(int r, String n, int c, double s, double cg) {
         rollno=r;
         name=n;
         contact=c;
         sgpa=s;
         cgpa=cg;
         }
         void displayInformation(){
         System.out.println("Roll No-"+rollno+" "+"name  "+name+"  Contact No."+contact+" sgpa- " +sgpa+" cgpa- " + cgpa);
         }
     
}

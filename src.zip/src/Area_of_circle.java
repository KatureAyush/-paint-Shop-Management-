
public class Area_of_circle {
    public static void main(String[] args)
    {
         int radius;
         radius=5;
         double pi=3.14,area;
         //caclulate the area of circle
         area=pi*radius*radius;
         System.out.println("Area of Circle is :" + area);
     
    }
}

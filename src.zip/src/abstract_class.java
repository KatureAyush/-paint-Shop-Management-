abstract class DigitalCamera {
    String make;
    String model;
    double megapixels;
    double price;
abstract void describe();
}
 class PointAndShoot extends DigitalCamera {
     void describe() {
	System.out.println("Digital Camera");
	System.out.printf("Make:       "+ make);
	System.out.printf("\t Model:      %s\n", model);
	System.out.printf("Megapixels: %.2f\n", megapixels);
	System.out.printf("Price:      %.2f", price);
    }
}
  
public class abstract_class {
    public static void main(String[] args) {
	DigitalCamera camera = new PointAndShoot();
	camera.make = "Olympus";
	camera.model = "FE-170";
	camera.megapixels = 6.0;
	camera.price = 119.95;
	camera.describe();
    }
}

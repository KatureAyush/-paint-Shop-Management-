abstract class Shape {
public abstract void draw();
  public abstract double area();  
  public abstract double circumference();
}
class Circle extends Shape {
  public static final double PI = 3.14;
  protected double r=6;
   public void draw(){
       System.out.println("Drawing circle");
   }
  public double area() { return PI*r*r; }
  public double circumference() { return 2*PI*r; }
}
class Rectangle extends Shape {
  protected double w=10, h=5; 
 public void draw(){
     System.out.println("Drawing rectangle");
 }                            
public double area() { return w*h; }
  public double circumference(){ 
      return 2*(w + h);
  } 
}
public class Abstact_demo {
    public static void main(String [] args)
    {
    Shape c1 = new Circle();
        Shape r1 = new Rectangle();
        c1.draw();
       System.out.println("Area of a Circle=  "+ c1.area());
        System.out.println("Circumference of a Circle=  "+ c1.circumference());

        r1.draw();
         System.out.println("Area of a Rectangle  =  "+r1.area());
         System.out.println("Circumference of a Rectangle=   "+r1.circumference());

    }
}
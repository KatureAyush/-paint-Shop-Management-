import java.awt.*;
import java.awt.Canvas;
import java.applet.*;
import java.awt.event.*;
public class Checkbox1 extends Applet implements ItemListener {
    Checkbox Red,Green,Blue;
    int a,b,c=0;
    
    public void itemStateChanged(ItemEvent e){
        
        if (Red.getState()==true){
             a=255;    
        }
        else{
            a=0;
        } 
        if (Green.getState()==true){
             b=255;
        }
        else {
             b=0;
        }
        if(Blue.getState()==true){
             c=255;     
        }
        else{
            c=0;
        }
        Color m= new Color(a,b,c);
    
            
        
}
    
    Font f= new Font(" Times New Roman",Font.BOLD,16);
    public void init(){
        
        Canvas cn;
        cn=new Canvas();
        cn.setSize(40,30);
        setFont(f);
        setLayout(null);
        setSize(30,30);
        cn.setBackground(m);
        Red= new Checkbox("Red");
        Green= new Checkbox("Green");
        Blue=new Checkbox("Blue");
        Red.setBounds(100, 100, 100, 50);
        Green.setBounds(300, 100, 100, 50);
        Blue.setBounds(500, 100, 100, 50);
        add(Red);
        add(Green);
        add(Blue);
        add(cn);
        Red.addItemListener(this);
        Green.addItemListener(this);
        Blue.addItemListener(this);
        
    }

}